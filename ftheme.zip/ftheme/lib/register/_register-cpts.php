<?php
/**
 * Register custom post types area.
 * @link https://codex.wordpress.org/Function_Reference/register_post_type
 */
add_action( 'init', function () {

} );