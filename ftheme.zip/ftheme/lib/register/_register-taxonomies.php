<?php
/**
 * Register taxonomies area.
 * @link https://codex.wordpress.org/Function_Reference/register_taxonomy
 */
add_action( 'init', function () {

} );