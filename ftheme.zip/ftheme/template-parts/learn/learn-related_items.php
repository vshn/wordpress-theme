<section class="wrapper related-items">
    <div class="container">
        <h2 class="title" >Also see</h2>
        <div class="items-wrapper">
            <a href="/" class="item">
                Our Blog
            </a>
            <a href="/" class="item">
                Events
            </a>
        </div>
    </div>
</section>
