<section class="s-products-content wrapper">
    <div class="container inner">
        <div class="content">
            <h3>Contact</h3>
            <p>VSHN AG<br>Neugasse 10<br>CH-8005 Zurich<br>Switzerland</p>
            <p>Telephone:&nbsp;<a href="tel:+41445455300">+41 44 545 53 00</a><br>Email:&nbsp;<a
                    href="mailto:info@vshn.ch">info@vshn.ch</a></p>
            <p>Company ID:&nbsp;CHE-275.566.226</p>
            <h3>Disclaimer</h3>
            <p>While VSHN AG has perused this website carefully, we do not take accountability for up-to-dateness,
                correctness, completeness or quality of the provided information and materials.</p>
            <h3>References and external links</h3>
            <p>VSHN AG does not have influence on directly or indirectly referenced websites of other providers and does
                not assume any liability for their availability and contents or for any potential damage emerging from
                accessing such websites.</p>
            <h3>Copyright</h3>
            <p>This website is copyrighted. No texts and/or pictures may be reproduced or used in other electronic or
                printed publications without prior written consent of VSHN AG.</p>
        </div>
    </div>
</section>