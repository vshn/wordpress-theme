<?php
/* Template Name: Example */
get_header(); ?>
    <div id="content" class="site-content">
        <?php
        headerPage(); ?>
        <main id="main" class="page-main site-main" role="main">

        </main>
    </div>
<?php
get_footer();