<section class="wrapper related-items">
    <div class="container">
        <h2 class="title" >Also see</h2>
        <div class="items-wrapper">
            <a href="/" class="item">
                Why VSHN?
            </a>
            <a href="/" class="item">
                Why DevOps?
            </a>
            <a href="/products" class="item">
                Our Products
            </a>
        </div>
    </div>
</section>
